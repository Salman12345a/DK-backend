import { ComponentLoader } from "adminjs";

// Initialize the component loader
const componentLoader = new ComponentLoader();

export default componentLoader;
